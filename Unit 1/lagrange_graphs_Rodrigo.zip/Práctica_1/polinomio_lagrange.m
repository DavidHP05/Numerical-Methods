function P = polinomio_lagrange(f, x_nodos)
% preparado para dar la funcion dada y los nodos del soporte de la
% discrtización
n = length(x_nodos);
P = 0;
%Evalamos la función en todos los nodos (y_i = f(x_i))
y_nodos = f(x_nodos);

for i = 1:n
    base_lagrange = L_i(i, x_nodos);
    P = P + y_nodos(i) * base_lagrange;
end
P = simplify(P); %Simplifica algebraicamente la expresión final
end