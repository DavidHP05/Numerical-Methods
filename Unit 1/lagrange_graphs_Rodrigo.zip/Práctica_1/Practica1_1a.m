syms x f(x)
f(x) = sin(3*x)
%Extremos del intervalo
a=0;
b=pi/4;
%Soporte con 2
n1 = 2;
soporte1 = linspace(a,b,n1);
y1 = f(soporte1);

%soporte con 3
n2 = 3;
soporte2 = linspace(a,b,n2);
y2 = f(soporte2);

%soporte con 10;
n3 = 10;
soporte3 = linspace(a,b,n3);
y3 = f(soporte3);

disp('Calculando polinomios simbólicos...');
P1 = polinomio_lagrange(f, soporte1);
P2 = polinomio_lagrange(f, soporte2);
P3 = polinomio_lagrange(f, soporte3);


% --- MOSTRAR EXPRESIONES ALGEBRAICAS EN PANTALLA ---
fprintf('\n======================================================\n');
fprintf('POLINOMIO P1 (2 puntos - Lineal):\n');
disp(P1);

fprintf('======================================================\n');
fprintf('POLINOMIO P2 (3 puntos - Cuadrático):\n');
disp(P2);
fprintf('======================================================\n');

fprintf('======================================================\n');
fprintf('POLINOMIO P3 (10 puntos - Cuadrático):\n');
disp(P3);
fprintf('======================================================\n');

% --- VISUALIZACIÓN Y COMPARATIVA ENTRE POL INTERPOLADOR Y F(X) ORIGINAL---
figure('Name', 'Comparativa de Soportes - Lagrange');

%Graficar la función original f(x)
fplot(f, [a, b], 'k-', 'LineWidth', 2.5); hold on;

%Graficar aproximación con 2 puntos
fplot(P1, [a, b], 'r--', 'LineWidth', 1.5);
plot(soporte1, y1, 'ro', 'MarkerFaceColor', 'r', 'MarkerSize', 6);

%Graficar aproximación con 3 puntos
fplot(P2, [a, b], 'b-.', 'LineWidth', 1.5);
plot(soporte2, y2, 'bs', 'MarkerFaceColor', 'b', 'MarkerSize', 6);

% Graficar aproximación con 10 puntos
fplot(P3, [a, b], 'g-.', 'LineWidth', 1.5);
plot(soporte3, y3, 'gs', 'MarkerFaceColor', 'g', 'MarkerSize', 6);

% Configuración estética de la gráfica
grid on;
xlim([a - 0.05, b + 0.05]);
ylim([-0.1, 1.1]);
title('Interpolación de Lagrange de f(x) = sin(3x) con diferentes soportes');
xlabel('x'); ylabel('y');
legend('f(x) original', 'P_1 (2 puntos)', 'Nodos P_1', 'P_2 (3 puntos)', 'Nodos P_2', 'P_3 (10 puntos)', 'Location', 'south');