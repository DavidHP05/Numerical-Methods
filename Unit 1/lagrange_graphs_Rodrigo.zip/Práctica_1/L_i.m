function pol_i = L_i(i, x_nodos)
syms x % Crea la variable simbólica x para la expresión analítica
n = length(x_nodos);
pol_i = 1; 

% Tu bucle con la lógica exacta de la productoria
for j = 1:n
    if j ~= i
        pol_i = pol_i * ((x - x_nodos(j)) / (x_nodos(i) - x_nodos(j)));
    end
end

pol_i = simplify(pol_i); % Simplifica la fórmula final
end